<div class="content_emp_details mt-5">
  <div class="table_box">
    <div class="title_emp_code_row">
      <div class="title_col">
        <h1>Krupa Jhaveri</h1>
      </div>

      <div class="emp_code">
        <p>Employee Code</p>
        <h5>K12335435</h5>
      </div>
    </div><!-- title_emp_code_row -->
    <div class="table-responsive mt-3">
        <table class="table table_employee">
          <thead>
            <tr>
              <th style="width:45%">Partner Name</th>
              <th style="width:33%">Partner Type</th>
              <th style="width:33%">Phone Number</th>
            </tr>
          </thead>

          <tbody>
            <tr>
              <td><span><i class="icon-user"></i> Puneet Mehta</span></td>
              <td><span><i class="icon-sale"></i> Sale</span></td>
              <td><a href="tel:8080002327"><i class="icon-phone"></i> 8080002327</a></td>
            </tr>
            <tr>
              <td><span><i class="icon-user"></i> Puneet Mehta</span></td>
              <td><span><i class="icon-service"></i> Service</span></td>
              <td><a href="tel:8080002327"><i class="icon-phone"></i> 8080002327</a></td>
            </tr>
            <tr>
              <td><span><i class="icon-user"></i> Puneet Mehta</span></td>
              <td><span><i class="icon-sale"></i> Sale</span></td>
              <td><a href="tel:8080002327"><i class="icon-phone"></i> 8080002327</a></td>
            </tr>
            <tr>
              <td><span><i class="icon-user"></i> Puneet Mehta</span></td>
              <td><span><i class="icon-service"></i> Service</span></td>
              <td><a href="tel:8080002327"><i class="icon-phone"></i> 8080002327</a></td>
            </tr>
          </tbody>
        </table>
    </div><!-- table-resposive -->
  </div>
</div><!-- content_emp_details -->
