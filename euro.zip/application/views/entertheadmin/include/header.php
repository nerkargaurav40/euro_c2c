<div id="header">
      <div class="header_inner">
          <div class="logo">
            <img src="<?php echo SITE_ASSETS; ?>images/logo-after-login.png" />
          </div>

          <div class="logo2">
            <!--<img src="<?php echo SITE_ASSETS; ?>images/logo-white.png" />-->
          </div>
      </div><!-- content -->
  </div><!-- header -->